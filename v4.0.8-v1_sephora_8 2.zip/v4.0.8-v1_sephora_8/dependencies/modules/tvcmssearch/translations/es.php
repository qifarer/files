<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmssearch}prestashop>ajax_8f4be21ec3cfbba15a349e9c5e888579'] = 'simbolo no valido	';
$_MODULE['<{tvcmssearch}prestashop>display_mobile_search_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Todos';
$_MODULE['<{tvcmssearch}prestashop>display_mobile_search_5bdba1fc0fba1010d61ce253c2e57da8'] = 'Busca en nuestro catálogo	';
$_MODULE['<{tvcmssearch}prestashop>display_mobile_search_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{tvcmssearch}prestashop>display_search_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Todos';
$_MODULE['<{tvcmssearch}prestashop>display_search_5bdba1fc0fba1010d61ce253c2e57da8'] = 'Busca en nuestro catálogo	';
$_MODULE['<{tvcmssearch}prestashop>display_search_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{tvcmssearch}prestashop>display_ajax_result_6e64c58f10e904c00b10721605500f52'] = 'Resultado de búsqueda:';
$_MODULE['<{tvcmssearch}prestashop>display_ajax_result_0487e300d8e02da2433b748586b15fa0'] = 'Mas resultados';
