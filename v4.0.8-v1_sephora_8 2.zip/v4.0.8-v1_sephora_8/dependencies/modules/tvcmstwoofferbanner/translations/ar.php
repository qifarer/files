<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_ae01fad2fade094df5bcae844e15c0a4'] = 'ثيميفولتي - بانر واحد';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_36ff97edbc230b2447d7504951e31469'] = 'هذا هو عرض بانر واحد في الجانب الأمامي';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'إعدادات';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_be53a0541a6d36f6ecb879fa2c584b08'] = 'صورة';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_4c6ace7405819bffddf7ee5133db4201'] = 'تعليق على الصورة';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_5dbade8dd1e626afef1bb69bacfd5d3a'] = 'أدخل تسمية توضيحية للصورة';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_97e7c9a7d06eac006a28bf05467fcc8b'] = 'حلقة الوصل';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_13efb468804622637985c1b2c31058d1'] = 'أدخل رابط الصورة';
$_MODULE['<{tvcmstwoofferbanner}prestashop>tvcmstwoofferbanner_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{tvcmstwoofferbanner}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'اختيار ملف';
