<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmsblogdisplayposts}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'اختيار ملف';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>form_840044224ccac6db80b0166cd7465655'] = 'الرجاء تحديد الصورة.';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayfooterposts_a5c22ff3efbced22c34bd7b7dd482a6d'] = 'اقرأ المزيد >>';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_home_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'تعليقات';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_home_0be8406951cdfda82f00f79328cf4efc'] = 'تعليقات';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_home_decbe415d8accca7c2c16d48a79ee934'] = 'اقرأ أكثر';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_home_f1e98a26384a5e804c97236b60cebfae'] = 'كل المدونات';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_left-bk_decbe415d8accca7c2c16d48a79ee934'] = 'اقرأ أكثر';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_left-bk_187b60ac731adde874b77f25f22f5df3'] = 'لم يتم العثور على وظيفة مدونة';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_left-bk_f1e98a26384a5e804c97236b60cebfae'] = 'كل المدونات';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_left_decbe415d8accca7c2c16d48a79ee934'] = 'اقرأ أكثر';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_left_187b60ac731adde874b77f25f22f5df3'] = 'لم يتم العثور على وظيفة مدونة';
$_MODULE['<{tvcmsblogdisplayposts}prestashop>tvcmsblogdisplayposts_left_f1e98a26384a5e804c97236b60cebfae'] = 'كل المدونات';
