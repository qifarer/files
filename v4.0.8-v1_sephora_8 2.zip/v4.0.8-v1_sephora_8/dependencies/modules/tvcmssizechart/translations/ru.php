<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmssizechart}prestashop>display_home_e67010114310da96b7cc2176f23e36a1'] = 'Руководство по размеру';
$_MODULE['<{tvcmssizechart}prestashop>display_home_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Перевозка';
$_MODULE['<{tvcmssizechart}prestashop>display_home_7966126831926ad29c528b239d69f855'] = 'Напишите свой отзыв';
