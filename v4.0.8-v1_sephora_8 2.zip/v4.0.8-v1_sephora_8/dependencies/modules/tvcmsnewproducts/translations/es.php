<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmsnewproducts}prestashop>tvcmsnewproducts_a45ef4d63f07070b3057d525e4bd57d2'] = 'Nuevo producto';
$_MODULE['<{tvcmsnewproducts}prestashop>tvcmsnewproducts_36270694395d506c0ba8fdc4cdbba249'] = 'Su nuevo producto en la parte frontal.	';
$_MODULE['<{tvcmsnewproducts}prestashop>display_home-data_e6af957192fa28b2dcf487ab2ccafc32'] = 'nuevo Banner de oferta	';
$_MODULE['<{tvcmsnewproducts}prestashop>display_home-data_a8c709d6c2db54c7b8274d5332de5ae0'] = 'Todos los productos nuevos	';
$_MODULE['<{tvcmsnewproducts}prestashop>display_side_product_a8c709d6c2db54c7b8274d5332de5ae0'] = 'Todos los productos nuevos	';
