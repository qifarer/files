<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmsfeaturedproducts}prestashop>tvcmsfeaturedproducts_31c8cd7d87c40710eb0c226eeb528727'] = 'منتج مميز';
$_MODULE['<{tvcmsfeaturedproducts}prestashop>tvcmsfeaturedproducts_4b78199f771a054cf16eef820b34e194'] = 'عرض المنتج المميز في الجانب الأمامي.	';
$_MODULE['<{tvcmsfeaturedproducts}prestashop>display_home-data_9a270cb0a829f36f779cc80464cf5d07'] = 'عرض بانر مميز	';
$_MODULE['<{tvcmsfeaturedproducts}prestashop>display_home-data_d6b6f1351c804f8c3566aab9ae292c55'] = 'جميع المنتجات المميزة	';
$_MODULE['<{tvcmsfeaturedproducts}prestashop>display_side_product_d6b6f1351c804f8c3566aab9ae292c55'] = 'جميع المنتجات المميزة	';
