<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmsmultibanner2}prestashop>tvcmsmultibanner2_76c2e4e92722741530b2ae4221809092'] = 'ThemeVolty - MultiBanner2';
$_MODULE['<{tvcmsmultibanner2}prestashop>tvcmsmultibanner2_0d50c44ae9ec35070efeab8d1f586b40'] = 'This is Show Multi-Banner2 in Front Side';
$_MODULE['<{tvcmsmultibanner2}prestashop>tvcmsmultibanner2_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
