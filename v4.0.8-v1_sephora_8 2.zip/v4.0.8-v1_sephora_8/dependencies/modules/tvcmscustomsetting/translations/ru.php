<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_2491bc9c7d8731e1ae33124093bc7026'] = 'Twitter';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_bf1981220040a8ac147698c85d55334f'] = 'RSS';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_970cfba66b8380fb97b742e4571356c6'] = 'Youtube';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_a1d7d2089dfd98072df7c45b07f9a89c'] = 'Google +';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_48c188f9cf89c7322ef33b75fc07e0a0'] = 'Pintrest';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_15db599e0119be476d71bfc1fda72217'] = 'Vimeo';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_55f015a0c5605702f913536afe70cfb0'] = 'Instagram';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_638f592f71fc3fac3351534e69f9d29f'] = 'добавить в корзину';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_bea8d9e6a0d57c4a264756b4f9822ed9'] = 'Мой аккаунт';
$_MODULE['<{tvcmscustomsetting}prestashop>display_custom_social_35dc41a87e863f4c5b72928e1674e515'] = 'Прокрутить вверх';
